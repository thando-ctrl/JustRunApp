package com.example.justrunapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class DisplayData : AppCompatActivity() {

    lateinit var viewDate : TextView
    lateinit var viewTime : TextView
    lateinit var viewComment: TextView
    lateinit var viewAverage : TextView
    lateinit var BackToMain: Button
    lateinit var ClearView: Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_data)

        val UserData = arrayListOf<Alldata>()

        viewDate = findViewById(R.id.DateView)
        viewTime = findViewById(R.id.TimeView)
        viewComment = findViewById(R.id.CommentView)
        viewAverage= findViewById(R.id.AvgView)
        BackToMain = findViewById(R.id.BtnMain)


        BackToMain.setOnClickListener {

            val intent2 = Intent(this,MainActivity::class.java)

            startActivity(intent2)
        }



        }


    }
