package com.example.justrunapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {

    lateinit var fromSplash : Button
    lateinit var turnOff : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fromSplash = findViewById(R.id.button)
        turnOff = findViewById(R.id.button2)

        fromSplash.setOnClickListener {

            val intent1 = Intent(this,Main2Activity::class.java)

            startActivity(intent1)
        }

        turnOff.setOnClickListener {

            finish()
        }

    }
}