package com.example.justrunapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText


// Class for the User data array
data class Alldata(val date: String,val time: String,val comment: String)

class Main2Activity : AppCompatActivity() {

    //Declaring User data array
    val UserData = arrayListOf<Alldata>()


    lateinit var getDate : EditText
    lateinit var getTime : EditText
    lateinit var getNote : EditText
    lateinit var savebtn : Button
    lateinit var clearbtn : Button
    lateinit var toNext : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mainactivity_main2)

        getDate = findViewById(R.id.etdate)
        getTime = findViewById(R.id.ettime)
        getNote = findViewById(R.id.etcomment)

        savebtn = findViewById(R.id.BtnSave)
        clearbtn = findViewById(R.id.BtnClear)
        toNext = findViewById(R.id.BtnNext)

        savebtn.setOnClickListener {

            val dateIn = getDate.text.toString()
            val timeIn = getTime.text.toString()
            val commentIn = getNote.toString()

            if (dateIn.isNotEmpty() && timeIn.isNotEmpty() && commentIn.isNotEmpty())
            {
                // Now we insert the data into the array list.

                UserData.add(Alldata("date","time","comment"))
                getDate.text.clear()
                getTime.text.clear()
                getNote.text.clear()
            }
        }
        clearbtn.setOnClickListener {

            UserData.clear()

        }
        toNext.setOnClickListener {

            val intent1 = Intent(this,DisplayData::class.java)

            startActivity(intent1)



        }
    }
}

